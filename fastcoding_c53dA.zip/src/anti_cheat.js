// anti cheat

// 开发模式禁用 anticheat
if (DEBUGGING) throw Error("deving no anti cheat");

(function() {
    // --- 开发者工具检测 ---

    function detectDevTools() {
        const minTimeThreshold = 100; 
        let startTime = new Date();
        
        debugger; 
        
        let endTime = new Date();
        
        if (endTime - startTime > minTimeThreshold) {
            // 为防止在重载时循环触发，只触发一次
            if (!window.devtoolsDetected) {
                window.devtoolsDetected = true;
                alert("检测到开发者工具！为保证竞赛公平，将清空页面。");
                document.body.innerHTML = "<div style=\"margin-top: 27px; margin-left: 27px;\"><h1>检测到违规操作</h1><p>请关闭开发者工具并刷新页面。</p></div>";
            }
        }
    }
    
    // 持续检测
// developing, stop checking for now
    setInterval(detectDevTools, 1500);

    // --- 阻止右键菜单 ---
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });

    // --- 阻止快捷键 ---
    document.addEventListener('keydown', function(e) {
        // F12
        if (e.key === 'F12' || e.keyCode === 123) e.preventDefault();
        // Ctrl+Shift+I / Cmd+Opt+I
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'I' || e.keyCode === 73)) e.preventDefault();
        // Ctrl+Shift+J / Cmd+Opt+J
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'J' || e.keyCode === 74)) e.preventDefault();
        // Ctrl+U
        if ((e.ctrlKey || e.metaKey) && (e.key === 'U' || e.keyCode === 85)) e.preventDefault();
    });


})();


// 4. 监听语言选择器的变化
document.getElementById('languageSelector').addEventListener('change', function() {
    var newLanguage = this.value;
    monaco.editor.setModelLanguage(editor.getModel(), newLanguage);
});

// --- 6. 复制/粘贴/右键菜单控制 (更新版) ---

// === 第一层防护：覆盖 Monaco 编辑器快捷键 ===

// a. 阻止 粘贴 (Ctrl+V / Cmd+V)
editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyV, function() {
    // 显示您指定的提示
    alert("不允许粘贴！如果您需要提交本地代码，请选择上传。");
});

// b. 阻止 复制 (Ctrl+C / Cmd+C)
editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyC, function() {
    // 什么也不做，阻止复制
});

// c. 阻止 剪切 (Ctrl+X / Cmd+X)
editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyX, function() {
    // 什么也不做，阻止剪切
});

// === 第二层防护：阻止鼠标和 DOM 事件 ===

// d. 阻止上下文菜单 (右键菜单)
editor.onContextMenu(function(e) {
    e.event.preventDefault(); 
    return false;
});

// e. 阻止 'paste' DOM 事件 (例如，中键粘贴)
editor.getDomNode().addEventListener('paste', function(e) {
    e.preventDefault(); 
    alert("不允许粘贴！如果您需要提交本地代码，请选择上传。");
    return false;
});

// f. 阻止 'copy' 和 'cut' DOM 事件 (以防万一)
editor.getDomNode().addEventListener('copy', function(e) {
    e.preventDefault();
    return false;
});

editor.getDomNode().addEventListener('cut', function(e) {
    e.preventDefault();
    return false;
});

function binding() {
    // 与 coding_logic.js 互联模块，防止通过 Burpsuite 篡改 anit_cheat.js
    throw Error("ANTI_CHEAT_RUNED");
}